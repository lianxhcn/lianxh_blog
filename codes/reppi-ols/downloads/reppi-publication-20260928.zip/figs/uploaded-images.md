![reppi-fig01-workflow-20260928-171943](https://fig-lianxh.oss-cn-shenzhen.aliyuncs.com/reppi-fig01-workflow-20260928-171943.png)

![reppi-fig02-crossfit-20260928-171943](https://fig-lianxh.oss-cn-shenzhen.aliyuncs.com/reppi-fig02-crossfit-20260928-171943.png)

![reppi-fig03-monte-carlo-20260928-171943](https://fig-lianxh.oss-cn-shenzhen.aliyuncs.com/reppi-fig03-monte-carlo-20260928-171943.png)
